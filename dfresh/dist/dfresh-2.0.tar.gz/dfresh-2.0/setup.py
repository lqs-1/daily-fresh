from setuptools import setup, find_packages

setup(
    name="dfresh",
    version="2.0",
    author="liqisong",
    author_email="749062870@qq.com",

    include_package_data=True,

    #  要被打包的项目
    packages=["dfresh"],


    # requires=[
    #     "django==4.0.4",
    #     "pymysql==1.0.2",
    #     "django-tinymce==3.4.0",
    #     "Pillow==9.1.1",
    #     "django-redis==5.2.0",
    #     "haystack==0.42",
    #     "itsdangerous==2.0.0",
    #     "celery==5.2.7",
    #     "django-cors-headers==3.12.0",
    #     "whoosh==2.7.4",
    #     "jieba==0.42.1",
    #     "pyOpenSSL==19.1.0",
    #     "../fdfs_client-py-master.zip"
    #     "python-alipay-sdk==3.0.4"
    #     "django-aliyun-oss2-storage==0.1.2"
    #
    # ]





)
